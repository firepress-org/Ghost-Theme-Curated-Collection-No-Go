core-icons
=========

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-icons) for more information.

## Building
Running `update-icons.sh` will checkout [material-design-icons](https://github.com/google/material-design-icons), reduce
the fileset to 24px svgs, and compile the iconsets.
