# from
https://github.com/kezzbracey/N-Coded

N-Coded
=======

A GitHub homage theme for the [Ghost Blogging platform](http://ghost.org "Ghost Blogging Platform") - forked from Casper, the default Ghost theme.

Visit Ghost at: [www.ghost.org](http://www.ghost.org "Ghost")

![N'Coded Screenshot](ncodedscreen.png?raw=true)
