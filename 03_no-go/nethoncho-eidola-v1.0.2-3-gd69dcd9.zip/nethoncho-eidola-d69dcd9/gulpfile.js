let gulp = require('gulp');
let clean = require('gulp-clean');
let concat = require('gulp-concat');
let rename = require("gulp-rename");
let cleanCSS = require('gulp-clean-css');
let sourcemaps = require('gulp-sourcemaps');
let sass = require('gulp-sass');
let browserSync = require('browser-sync').create();

gulp.task('clean', function() {
  return gulp.src(['*~', 'src/**/*~', 'test/*~', '*.log', 'partials/*~'], {read: false})
    .pipe(clean());
});

gulp.task('sass', function() {
  return gulp.src(['src/scss/eidola.scss'])
    .pipe(sass().on('error', sass.logError))
    .pipe(gulp.dest('assets/css'))
    .pipe(sourcemaps.init())
    .pipe(cleanCSS())
    .pipe(rename({ extname: '.min.css' }))
    .pipe(sourcemaps.write('.'))
    .pipe(gulp.dest('assets/css'))
    .pipe(browserSync.stream());
});

gulp.task('serve', ['sass'], function() {
  browserSync.init({
    open: false,
    server: {
      baseDir: 'test',
      index: 'bootstrap-test.html',
      routes: {
        '/assets': 'assets'
      }
    }
  });

  gulp.watch(['src/scss/*.scss'], ['sass']);
  gulp.watch("test/*").on('change', browserSync.reload);
});

gulp.task('default', ['sass']);
