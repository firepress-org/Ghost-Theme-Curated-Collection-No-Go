# eidola
A [bootstrap 4](http://getbootstrap.com/) theme for [ghost](https://ghost.org/)

## Screenshots

Desktop
=======
[![Eidola Desktop](https://raw.githubusercontent.com/nethoncho/eidola/master/assets/eidola-desktop-screenshot.jpg)](#features)

Mobile
======
[![Eidola Mobile](https://raw.githubusercontent.com/nethoncho/eidola/master/assets/eidola-mobile-screenshot.jpg)](#features)
