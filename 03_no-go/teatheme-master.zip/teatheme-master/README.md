# Tea Theme

A theme for blogging with ghost. Example: https://veganteaparty.club/

Runs on version 1.5.2
