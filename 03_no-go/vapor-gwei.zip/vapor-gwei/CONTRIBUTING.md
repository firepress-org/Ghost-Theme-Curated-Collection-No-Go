# Contributing

Contributions to the Vapor code base are welcome and encouraged! Fork the repo, write your code, test your changes, then submit a [pull request](https://github.com/sethlilly/Vapor/pulls). Including a test URL in your PR will speed things up on our side. Thanks for contributing to this open source theme for Ghost!
