# Contributing

Contributions to the Bentley code base are welcome and encouraged! Fork the repo, write your code, test your changes, then submit a [pull request](https://bitbucket.org/Caffein8/bentley/pull-requests). Including a test URL in your PR will speed things up on our side. Thanks for contributing to this open source theme for Ghost!