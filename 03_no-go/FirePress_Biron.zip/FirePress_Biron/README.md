# FirePress_Biron


## What is this?

- **FirePress_Biron** — It’s a free and responsive Ghost theme (*a template if you prefer*) made for Ghost.
- **Compatibility** — This theme works on Ghost `>= 2.0.0`.
- **What is Ghost?** — Ghost is an open source software that lets you create your website with a blog. See the [FAQ section](https://play-with-ghost.com/ghost-themes/faq/#what-is-ghost) for more details.


## Live Demo

**play-with-ghost.com** is a playground to learn about Ghost. You can **see** Ghost themes and **login** into the admin panel by using the available credentials. In short, you can try Ghost on the spot without having to sign-up!

- **Live Demo** ==> https://play-with-ghost.com/live-demo-firepress-biron-for-barbershops/
- **Log in credentials** ==> https://play-with-ghost.com/ghost-themes/firepress-biron-for-barbershops/
- **Admin Panel** ==> https://play-with-ghost.com/live-demo-firepress-biron-for-barbershops/ghost/


## Why fork this Ghost Theme ?

- **Enhancements** — This theme has been enhanced to feature some elements that are not present in the original theme. IMHO, these are essential enhancements that are hard to live without:
	- **Code Syntax** (highlight.js) 
- **Drop-in replacement** — No special tweaks to do. It will work out of the box.
- **Code Injection** — Take a look those snippets in this [Git repo](https://github.com/firepress-org/Code-Injection-Ghost). It’s an easy way to customize your theme.
- **Curated** — This theme was carefully selected out of hundreds of Ghost Themes. See more of them in our [Ghost-Theme-Curated-Collection ](https://github.com/firepress-org/Ghost-Theme-Curated-Collection/tree/master/01_go) repo, or [by tags on Github](https://github.com/topics/firepress-ghost-theme).

I didn’t include those elements in this theme as there are styling (CSS) conflicts. I might work on this in the future depending on the feedback I get.

- **Buttons** (unicorn UI)
- **Icons** (Font Awesome 5)
- **Grid** (great to make pricing table)
	
## Features

- Fully Responsive Bulma CSS is a responsive css framework, making the theme fully responsive. Biron was designed with a mobile first approach and it works great on all display sizes, be it mobile, tablet or desktop.
- Translation Support — Biron supports Ghost i18n for theme translation. The theme is translation ready, meaning it’s really easy to add a new language to it. Check out the documentation for more details.
- Subscription Form — Support for Ghosts Subscription Form, making it easy to grow your mailing list as well as switching it on/off.
- Custom Logo Support — Support for Custom Logo, just upload the logo in the admin panel and the rest is taken care of.
- Syntax Highlighting Biron uses Prism for syntax highlighting. It’s already built in so you don’t have to worry about adding it to the theme. Using it it’s really simple.
- Related Posts — Related Posts assures you are suggesting relevant articles to your readers, making them more likely to stay on your website. Posts will be shown checking for common tags within posts.
- Disqus Comments — Biron has Disqus comments integrated, all you need to do is change the disqus shortname and you are good to go.
- Support for Static Pages Biron comes with support for Static Pages, just check the ‘Static page’ checkbox in the post settings section. Besides static page support Biron comes with a couple of Custom Pages:
- Documentation — We will provide a detailed documentation covering everything you need starting from installing the theme to customizing it according to your needs.
- Easy to Customize Biron was developed using the latest technologies and tools in web development. Check out the development part in the documentation.


## Contributing

Here’s how I suggest you go about proposing a change to this project:

1. [Fork this project](https://help.github.com/articles/fork-a-repo/) to your account.
2. [Create a branch](https://help.github.com/articles/creating-and-deleting-branches-within-your-repository/) for the change you intend to make (i.e. `git checkout -b my-new-feature`)
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. [Submit a pull request](https://help.github.com/articles/about-pull-requests/) from your fork’s branch to our `master` branch.
	- Explain why you’re making a change. Even if it seems self-evident, please take a sentence or two to tell us why your change or addition should happen. It’s especially helpful to articulate why this change applies to everyone who works with the applicable technology, rather than just you or your team.
	- Please only modify one element per pull request. This helps keep pull requests and feedback focused on a specific project or technology.


## Sources & Fork

- This Git repo is available at https://github.com/firepress-org/FirePress_Biron
- This project was forked from https://github.com/bironthemes/biron-ghost-theme


## License

- This fork is under the **GNU** license. Details at https://github.com/pascalandy/GNU-GENERAL-PUBLIC-LICENSE
- This theme is under the **MIT** license. Details at https://github.com/bironthemes/biron-ghost-theme/blob/master/LICENSE


## FirePress Hosting

At FirePress we do one thing and we do it with our whole heart: we host **fully managed Ghost’s websites**. The idea behind FirePress is to empower freelancers and small organizations to be able to build an outstanding mobile-first website. Start your [free trial here](https://play-with-ghost.com/ghost-themes/free-10-day-trial/).

We offer **workshops** where participants ends up with a website/blog they can easily operate themselves. Details are coming soon. It is available in those cities:

- Montréal - Canada
- Québec City - Canada
- Toronto - Canada
- New-York - USA

Because we believe your website should speak up in your name, we consider our mission completed once your site has become [your impresario](https://play-with-ghost.com/ghost-themes/why-launching-your-next-website-with-firepress/).


## Keep in touch

- Pascal Andy’s [« now page »](https://pascalandy.com/blog/now/)
- Follow me on [Twitter](https://twitter.com/askpascalandy)
- Find more Ghost Themes on [play-with-ghost.com](https://play-with-ghost.com/)


## Screenshots

wip