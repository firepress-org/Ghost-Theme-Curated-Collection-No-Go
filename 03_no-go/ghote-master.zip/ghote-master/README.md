# ghote

[![Ghost version](https://img.shields.io/badge/Ghost-1.x-brightgreen.svg?style=flat-square)](https://ghost.org/)
[![Node version](https://img.shields.io/node/v/uno-zen.svg?style=flat-square)](https://nodejs.org/en/)
[![Donate](https://img.shields.io/badge/donate-paypal-blue.svg?style=flat-square)](https://paypal.me/silasjelley)

A demo/example is available [here](https://forkinthesand.com).

## Features
* Fully responsive design.
* Site wide search.
* Intuituve desktop navigation.
* Unobtrusive mobile navigation.
* Social media and sharing links.
* Support for email collection.
* AMP template.
* Infinite scroll pagination.
* Comments support (Disqus or Facebook).

![](./readme/screenshot.png)


### Credit
This theme originated as [godofredoninja's](https://github.com/godofredoninja) [mapache](https://github.com/godofredoninja/Mapache) theme.
