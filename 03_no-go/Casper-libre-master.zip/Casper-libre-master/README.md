# Casper-libre

Casper-libre is based on the default theme for [Ghost](http://github.com/tryghost/ghost/). 
This is the latest version of Casper-libre. I will merge my changes with the upstream version of Casper available here: [Casper](https://github.com/TryGhost/Casper)


# What is different between Casper and Casper-libre?

Casper has an annoying "feature" that Casper-libre does not have: Facebook and Twitter integration.
On every story that you write, It displays a share button for Facebook and Twitter. I do not use Facebook or Twitter, and I don't support the use of them. So I did what any good hacker would and fork the theme and fix the issue!

# Planned Features

I am not against social networks, so I will be adding integration with the following privacy and freedom respecting social networks:

* [Mastodon](https://github.com/tootsuite/mastodon)

Feel free to make a feature request in the issue tracker If you want another site added to the theme.

# Copyright & License

Copyright (c) 2018 Winter Jones - Released under the [General Public License Version 3](LICENSE).

