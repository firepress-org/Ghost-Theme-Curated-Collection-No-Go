# Satou

A minimalistic ghost theme.  

## Screenshot
![Screenshot](https://i.imgur.com/FsCYgKU.png)

## Copyright & License
Copyright (c) 2018 Khinenw - Released under the [MIT license](LICENSE).
