<nav id="navigation">

</nav>

<style lang="less">
	#navigation {
		width: 300px;
		height: 100vh;

		position: fixed;
		top: 0;
		right: -300px;
		bottom: 0;

		display: flex;
		flex-direction: column;
	}
</style>
