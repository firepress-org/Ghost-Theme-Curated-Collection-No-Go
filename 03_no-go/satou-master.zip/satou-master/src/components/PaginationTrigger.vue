<template>
	<div class="pagination-trigger"></div>
</template>
