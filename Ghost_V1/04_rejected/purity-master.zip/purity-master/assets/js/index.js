/**
 * Main JS file for Casper behaviours
 */
