# MSCC Ghost theme
Ghost theme used on [MSCC website](https://www.mscc.mu).
