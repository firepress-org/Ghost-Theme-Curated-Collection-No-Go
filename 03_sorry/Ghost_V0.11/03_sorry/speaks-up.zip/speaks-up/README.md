# from
https://github.com/jorr92/speaksup