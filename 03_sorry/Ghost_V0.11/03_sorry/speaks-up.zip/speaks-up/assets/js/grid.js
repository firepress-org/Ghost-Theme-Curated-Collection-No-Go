/*global $*/
$('.posts-grid').isotope({
  itemSelector: '.post',
  layoutMode: 'masonry'
});
