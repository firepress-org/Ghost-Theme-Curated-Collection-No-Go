# from 
https://github.com/cnunciato/ghost-content