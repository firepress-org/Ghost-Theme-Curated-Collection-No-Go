# CONTRIBUTING

## RESOURCES

If you wish to contribute to Casperion, please be sure to read to the following resources:

 -  Git Guide: [README-GIT.md](README-GIT.md)

If you are working on new features, or refactoring an existing
component, please create a proposal. You can do this in on the RFC's
page, https://github.com/sandrokeil/ghost-theme-casperion/wiki/RFCs.
