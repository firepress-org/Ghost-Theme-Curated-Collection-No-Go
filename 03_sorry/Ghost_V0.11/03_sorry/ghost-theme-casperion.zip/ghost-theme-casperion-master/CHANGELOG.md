# Casperion CHANGELOG

## 1.2.0 (2016-02-28)
- update to latest Ghost version 0.7.8

## 1.1.2 (2015-06-18)
- [#6](https://github.com/sandrokeil/ghost-theme-casperion/issues/6) fixed blog cover was not displayed

## 1.1.1 (2015-05-21)
- Fixed menu mobile padding issue
- Fixed footer and read next mobile margin issues
- Fixed table not horizontal scrollable mobile issue

## 1.1.0 (2015-04-28)

- Updated navigation.hbs for Ghost 0.6
- Updated dev dependencies
- Ghost 0.6.2 compatible
- Minor SEO optimizations

## 1.0.0 (2014-12-08)

- Initial release
- Ghost 0.5.6 compatible
