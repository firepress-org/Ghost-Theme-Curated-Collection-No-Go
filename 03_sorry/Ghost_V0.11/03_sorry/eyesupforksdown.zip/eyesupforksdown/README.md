# from
https://github.com/enlore/blog.eufd