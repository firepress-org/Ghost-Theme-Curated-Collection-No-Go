# Aside

A theme for [Ghost](http://github.com/tryghost/ghost/) based on the default theme, Casper. 

##Important Notes

Make sure you change both the Google Analytics and Disqus keys before using this on your site.
